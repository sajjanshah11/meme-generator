import React from 'react';
import Weather from "./Weather"

const App = () => {
  return (
    <>
      <Weather />
    </>
  );
}

export default App;
